const router = require('express').Router()
// const userController = require('../api/user/userController')
const categoryController = require('../api/category/categoryController')

// router.post('/user/add', userController.add)


// =====================category=========================
router.post('/category/add', categoryController.add)
// =====================category=========================


router.all("**", (req, res)=>{
    res.send({
        success:false,
        status:404,
        message:"Invalid Address"
    })
})

module.exports = router
const categoryModel = require('./categoryModel')

const add = async (req, res)=>{
    let validations = ""

    if(!req.body.name){
        validations += "Name is Required "
    }
    if(!req.body.description){
        validations += "Description is Required "
    }

    if(!!validations){
        res.send({
            success:false,
            status:422,
            message:"Validation Error : "+validations
        })
    }
    else{
        let total = await categoryModel.countDocuments()
        let category = new categoryModel({
            autoId: total+1,
            name:req.body.name,
            description:req.body.description
        })
        category.save()
        .then((result)=>{
            res.send({
                success:true,
                status:200,
                message:"New Category Created",
                data:result
            })
        })
        .catch((err)=>{
            res.send({
                success:false,
                status:500,
                message:err.message
            })
        })
    }
}

module.exports = { add }
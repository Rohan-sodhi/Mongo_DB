const mongoose = require('mongoose')

const categorySchema = new mongoose.Schema({
    id: { type: Number, default: 0 },
    autoId: { type: Number, default: 0 },
    name: { type: String, default: "" },
    thumbnail: { type: String, default: "" },
    createdAt: { type: Date, default: Date.now() },
    status: { type: Boolean, default: true },

})
module.exports = mongoose.model("category", categorySchema) 
const categoryModel = require("./categoryModel")

const all = (req, res) => {
    req.body.status = true
    categoryModel.find(req.body).exec()
        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "All Documents Loaded",
                data: result
            })
        })
        .catch((err) => {
            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}

module.exports = { all }
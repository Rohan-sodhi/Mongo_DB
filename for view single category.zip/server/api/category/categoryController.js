const categoryModel = require("./categoryModel")

const single = (req, res)=>{
    let validation = ""
    if(!req.body._id){
        validation +=" _id is required "
    }


    if(!!validation){
        res.send({
            success:false,
            status:422,
            message:"Validation Error "+validation
        })
    }
    else{
        categoryModel.findOne({_id:req.body._id}).exec()
        .then((result)=>{
            if(result == null){
                res.send({
                    success:false,
                    status:404,
                    message:"Category Does not exist"
                })
            }
            else{
                res.send({
                    success:true,
                    status:200,
                    message:"Single Document Loaded",
                    data:result
                })
            }
        })
        .catch((err)=>{
            res.send({
                success:false,
                status:500,
                message:err.message
            })
        })
    }
    
}

module.exports = { single }
const router = require("express").Router()
const categoryController = require("../api/category/categoryController")

router.post("/delete",categoryController.deleteFun)



router.all("**", (req, res) => {
    res.send({
        success: false,
        status: 404,
        message: "Invalid Address"
    })
})

module.exports = router